from django.apps import AppConfig


class Jxlg0102AuthConfig(AppConfig):
    name = 'apps.jxlg0102auth'
