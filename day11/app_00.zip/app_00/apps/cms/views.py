from django.shortcuts import render,reverse,redirect
from django.http import HttpResponse
from django.views import View
# Create your views here.
class AddBookView(View):
    def post(self,request,*args,**kwargs):
        return render(request,"cms/add_book.html")

    def http_method_not_allowed(self, request, *args, **kwargs):
        return HttpResponse("您当前采用的method是：%s，本视图只支持使用post请求！" % request.method)
class SuperUserLoginView(View):
    def get(self,request):
        return render(request,'cms/login.html')
    def post(self,request):
        return redirect(reverse('add_book'))
