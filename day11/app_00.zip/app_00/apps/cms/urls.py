from django.urls import path
from . import views
app_name = 'cms'
urlpatterns =[
    path('login/', views.SuperUserLoginView.as_view(), name='login'),
    path('add_book/', views.AddBookView.as_view(), name='add_book'),
]