# encoding:utf-8
from flask import Flask, render_template
from flask_script import Manager

# 创建实例
flask_b = Flask(__name__)

manager = Manager(flask_b)

# 视图函数
@flask_b.route('/')
def index():
    context = {
        'username': '名字',
        'age': 15,
        'country': 'china',
        'scripts': '<script>alert("heheh")</script>',
        'childrens': {
            'name': 'test',
            'height': '233cm'
        }
    }
    return render_template('index.html',**context )

# 启动

if __name__ == '__main__':
    flask_b.run(debug=True, threaded=True)
    # manager.run()